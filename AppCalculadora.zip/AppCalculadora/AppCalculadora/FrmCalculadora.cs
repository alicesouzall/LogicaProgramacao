﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCalculadora
{
    public partial class FrmCalculadora : Form
    {
        public FrmCalculadora()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            //Criar variáveis e capturar dados
            float numero1 = float.Parse(txtN1.Text);
            float numero2 = float.Parse(txtN2.Text);
            float soma;

            //Processamento e cálculo
            soma = numero1+numero2;

            //Saída - mostrar
            MessageBox.Show("Soma igual a " + soma);
            

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            //Criar variáveis e capturar dados
            float numero1 = float.Parse(txtN1.Text);
            float numero2 = float.Parse(txtN2.Text);
            float subtrair;

            //Processamento e cálculo
            subtrair = numero1 - numero2;

            //Saída - mostrar
            MessageBox.Show("Subtração igual a " + subtrair);

        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            //Criar variáveis e capturar dados
            float numero1 = float.Parse(txtN1.Text);
            float numero2 = float.Parse(txtN2.Text);
            float multiplicar;

            //Processamento e cálculo
            multiplicar = numero1 * numero2;

            //Saída - mostrar
            MessageBox.Show("Multiplicação igual a " + multiplicar);

        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            //Criar variáveis e capturar dados
            float numero1 = float.Parse(txtN1.Text);
            float numero2 = float.Parse(txtN2.Text);
            float divisao;

            //Processamento e cálculo
            divisao = numero1 / numero2;

            //Saída - mostrar
            MessageBox.Show("Soma igual a " + divisao);

        }
    }
}
