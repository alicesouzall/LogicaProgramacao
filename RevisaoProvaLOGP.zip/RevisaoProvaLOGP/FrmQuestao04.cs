﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppProva01AliceSouza
{
    public partial class FrmQuestao04 : Form
    {
        public FrmQuestao04()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float minimo = float.Parse(txtMinimo.Text);
            float funcionario = float.Parse(txtFuncionario.Text);
            float resultado;

            resultado = funcionario / minimo;

            MessageBox.Show("O funcionário recebe " + resultado +" salários mínimos.");
        }
    }
}
