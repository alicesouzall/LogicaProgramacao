﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppProva01AliceSouza
{
    public partial class FrmQuestao03 : Form
    {
        public FrmQuestao03()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float altura = float.Parse(txtAltura.Text);
            float maior = float.Parse(txtMaior.Text);
            float menor = float.Parse(txtMenor.Text);
            float area;

            area = ((maior + menor)*3)/2;

            lblResultado.Text = area.ToString();
        }
    }
}
