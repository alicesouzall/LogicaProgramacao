﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class FrmEx05 : Form
    {
        public FrmEx05()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float baseret = float.Parse(txtBase.Text);
            float altura = float.Parse(txtAltura.Text);
            float perimetro;
            float area;

            area = baseret * altura;
            perimetro = baseret * 3;

            MessageBox.Show("A área do triângulo é: " + area + " e seu perímetro é: "+perimetro);
        }
    }
}
