﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class FrmEx02 : Form
    {
        public FrmEx02()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float litro = float.Parse(txtLitro.Text);
            float valor = float.Parse(txtValor.Text);
            float resultado;

            resultado = valor / litro;

            MessageBox.Show("O motorista pode abastecer o carro com " + resultado + " litros.");
        }
    }
}
