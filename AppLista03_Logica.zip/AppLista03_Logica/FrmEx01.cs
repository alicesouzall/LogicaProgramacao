﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class FrmEx01 : Form
    {
        public FrmEx01()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float soma;

            soma = num1 + num2 + num3;

            MessageBox.Show("Soma: " + soma);

        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float media;

            media = (num1 + num2 + num3)/3;

            MessageBox.Show("Média:" + media);
        }

        private void btnPorc_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float porc1;
            float porc2;
            float porc3;

            porc1 = num1/(num1+num2+num3)*100;
            porc2 = num2 / (num1 + num2 + num3) * 100;
            porc3 = num3 / (num1 + num2 + num3) * 100;

            MessageBox.Show("Porcentagem do NUM 1: " + porc1 + "; Porcentagem do NUM 2: " + porc2 + "; Porcentagem do NUM 3: " + porc3);

        }
    }
}
