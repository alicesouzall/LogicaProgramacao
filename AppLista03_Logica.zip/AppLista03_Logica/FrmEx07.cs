﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class FrmEx07 : Form
    {
        public FrmEx07()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int camisetaP = int.Parse(txtP.Text);
            int camisetaM = int.Parse(txtM.Text);
            int camisetaG = int.Parse(txtG.Text);
            int resultado;

            resultado = 12 * camisetaP + 16 * camisetaM + 22 * camisetaG;

            MessageBox.Show("O valor total é " + resultado);
        }
    }
}


